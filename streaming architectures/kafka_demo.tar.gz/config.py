kafka_loc = 'localhost:9092';
schema_reg_loc = 'http://localhost:8081';
