from confluent_kafka import avro, TopicPartition
from confluent_kafka import KafkaError
from confluent_kafka.avro import AvroProducer, AvroConsumer
from confluent_kafka.avro.serializer import SerializerError
from datetime import datetime
from config import kafka_loc, schema_reg_loc

seed_pop = 100001;

key_schema = avro.loads("""
{
   "namespace": "volkszaehlung",
   "name": "key",
   "type": "record",
   "fields" : [
     {
       "name" : "ts",
       "type" : "string"
     }
   ]
}
""");

value_schema_str = """
{
   "namespace": "volkszaehlung",
   "name": "value",
   "type": "record",
   "fields" : [
     {
       "name" : "einwohnerzahl",
       "type" : "int"
     }
   ]
}
"""
value_schema = avro.loads(value_schema_str);
topic = "einwohnerzahl";

c = AvroConsumer({
    'bootstrap.servers': kafka_loc,
    'group.id': 3,
    'schema.registry.url': schema_reg_loc,
    'default.topic.config': {'auto.offset.reset': 'smallest'}
    });

parts = [TopicPartition('geburten',0,0),
         TopicPartition('todesfaelle',0,0),
         TopicPartition('zuwanderungen',0,0),
         TopicPartition('abwanderungen',0,0)]
c.commit(offsets=parts, async=False)

def main():
    consumeAllTopics();


def consumeAllTopics():
    global seed_pop;
    c.subscribe(['geburten', 'todesfaelle', 'zuwanderungen', 'abwanderungen']);
    consuming = True;
    while consuming:
        try:
            msg = c.poll(10);
        except SerializerError as e:
            print("Deserialisierung fehlgeschlagen {}: {}".format(msg, e));
            break;
        if msg is None:
            continue;
        if msg.error():
            if msg.error().code() == KafkaError._PARTITION_EOF:
                consuming = False;
                break;
            else:
                print(msg.error());
                break;
        if msg.topic() in ['geburten', 'zuwanderungen']:
            seed_pop = seed_pop + 1;
        if msg.topic() in ['todesfaelle', 'abwanderungen']:
            seed_pop = seed_pop - 1;
    c.close();
    updateEinwohnerzahl(seed_pop);


def updateEinwohnerzahl(_newVal):
    update = {"einwohnerzahl" : _newVal};
    postToKafka(update);


def postToKafka(_value):
    print("/" + topic + " <== "  + str(_value))
    key = {"ts": str(datetime.now())}
    avroProducer = AvroProducer({
      'bootstrap.servers': kafka_loc,
      'schema.registry.url': schema_reg_loc
      }, default_key_schema=key_schema, default_value_schema=value_schema)
    avroProducer.produce(topic=topic, value=_value, key=key)
    avroProducer.flush()



if __name__ == "__main__":
    main()
