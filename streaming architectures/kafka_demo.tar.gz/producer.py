from confluent_kafka import avro
from confluent_kafka.avro import AvroProducer
from datetime import datetime
import time
from random import randint
from data_generator import *
from config import kafka_loc, schema_reg_loc

def main():
    while(True):
        switch = [geburt, tod, zuwanderung, abwanderung];
        switch[randint(0, 3)]();
        time.sleep(.300);


key_schema = avro.loads("""
{
   "namespace": "volkszaehlung",
   "name": "key",
   "type": "record",
   "fields" : [
     {
       "name" : "ts",
       "type" : "string"
     }
   ]
}
""");



def geburt():
    value_schema_str = """
    {
       "namespace": "volkszaehlung",
       "name": "value",
       "type": "record",
       "fields" : [
         {
           "name" : "vorname",
           "type" : "string"
         },
         {
           "name" : "nachname",
           "type" : "string"
         },
         {
           "name" : "geburtsort",
           "type" : "string"
         }
       ]
    }
    """
    postToKafka(generateGeburt(), value_schema_str, "geburten");
    return;



def tod():
    value_schema_str = """
    {
       "namespace": "volkszaehlung",
       "name": "value",
       "type": "record",
       "fields" : [
         {
           "name" : "vorname",
           "type" : "string"
         },
         {
           "name" : "nachname",
           "type" : "string"
         },
         {
           "name" : "todesort",
           "type" : "string"
         }
       ]
    }
    """
    postToKafka(generateTod(), value_schema_str, "todesfaelle");
    return;



def zuwanderung():
    value_schema_str = """
    {
       "namespace": "volkszaehlung",
       "name": "value",
       "type": "record",
       "fields" : [
         {
           "name" : "vorname",
           "type" : "string"
         },
         {
           "name" : "nachname",
           "type" : "string"
         },
         {
           "name" : "ursprung",
           "type" : "string"
         }
       ]
    }
    """
    postToKafka(generateZuwanderung(), value_schema_str, "zuwanderungen");
    return;



def abwanderung():
    value_schema_str = """
    {
       "namespace": "volkszaehlung",
       "name": "value",
       "type": "record",
       "fields" : [
         {
           "name" : "vorname",
           "type" : "string"
         },
         {
           "name" : "nachname",
           "type" : "string"
         },
         {
           "name" : "zielland",
           "type" : "string"
         }
       ]
    }
    """
    postToKafka(generateAbwanderung(), value_schema_str, "abwanderungen");
    return;



def postToKafka(_value, _value_schema, _topic):
    print("/" + _topic + " <== "  + str(_value));
    value_schema = avro.loads(_value_schema);
    key = {"ts": str(datetime.now())};
    avroProducer = AvroProducer({
      'bootstrap.servers': kafka_loc,
      'schema.registry.url': schema_reg_loc
      }, default_key_schema=key_schema, default_value_schema=value_schema);
    avroProducer.produce(topic=_topic, value=_value, key=key);
    avroProducer.flush();



if __name__ == "__main__":
    main()
