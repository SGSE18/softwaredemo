from confluent_kafka import avro, TopicPartition
from confluent_kafka import KafkaError
from confluent_kafka.avro import AvroProducer, AvroConsumer
from confluent_kafka.avro.serializer import SerializerError
from datetime import datetime
from config import kafka_loc, schema_reg_loc

key_schema = avro.loads("""
{
   "namespace": "volkszaehlung",
   "name": "key",
   "type": "record",
   "fields" : [
     {
       "name" : "ts",
       "type" : "string"
     }
   ]
}
""");

value_schema_str = """
{
   "namespace": "volkszaehlung",
   "name": "value",
   "type": "record",
   "fields" : [
     {
       "name" : "vorname",
       "type" : "string"
     },
     {
       "name" : "nachname",
       "type" : "string"
     },
     {
       "name" : "ursprung",
       "type" : "string"
     },
     {
       "name" : "alter",
       "type" : "int",
       "default": 0
     }
   ]
}
"""
value_schema = avro.loads(value_schema_str);
topic = "zuwanderungen";

def main():
    new_guy = {
        "vorname": "Harald",
        "nachname": "Hansen",
        "ursprung": "Wakanda",
        "alter": 15
    };
    postToKafka(new_guy);

def postToKafka(_value):
    print("/" + topic + " <== "  + str(_value))
    key = {"ts": str(datetime.now())}
    avroProducer = AvroProducer({
      'bootstrap.servers': kafka_loc,
      'schema.registry.url': schema_reg_loc
      }, default_key_schema=key_schema, default_value_schema=value_schema)
    avroProducer.produce(topic=topic, value=_value, key=key)
    avroProducer.flush()


if __name__ == "__main__":
    main()
