# -*- coding: utf-8 -*-
import random

vornamen = ["Marie", "Maximilian", "Sophie", "Alexander",
"Maria", "Paul", "Sophia", "Elias", "Emilia", "Ben",
"Emma", "Noah", "Hannah", "Leon", "Anna", "Louis",
"Luisa", "Jonas", "Mia", "Felix", "Wolf"];

nachnamen = ["Mueller", "Schmidt", "Fischer", "Huber",
"Bauer", "Schneider", "Wagner", "Weber", "Schmid",
"Maier", "Mayer", "Nguyen", "Hoffmann", "Wolf", "Meyer",
"Richter","Fuchs", "Schwarz", "Lang", "Hofmann", "Louis"];

orte = ["Sonnentann", "Adlerspass", "Wolkennest", "Schwalbenbruch",
"Finstersumpf", "Hochbach", "Wolfswalde", "Buerenhain",
"Fuchsstrom", "Schwalbentann", "Tiefmeer", "Hochhain",
"Doerrbruch", "Klingensee", "Brachstein", "Sternenhain",
"Tiefsumpf", "Wolkenstrom", "Oberbach", "Falkenberge",
"Falkenstrom", "Sonnenschlucht", "Finsterbach", "Unterwacht",
"Goldbruch", "Dustersumpf", "Dusterwueste", "Durrburg",
"Eichensumpf", "Buerensee", "Schoensteig", "Adlerstann",
"Blitzmeer", "Goldfurt", "Silberwacht", "Drachennest",
"Donnerhain", "Feuerstein", "Schoenhuegel", "Doerrhuegel",
"Hochstadt", "Adlersstiege", "Adlersbruch", "Adlersfelde",
"Trutzstiege", "Silberberge", "Doerrsee", "Tiefstein",
"Blitzfelde", "Hochhuegel", "Goldwueste", "Feuertann",
"Tiefbach", "Mondpass", "Schoenhain", "Trutzstrom"];

laender = ["Russland", "Kanada", "Vereinigte Staaten", "China",
"Brasilien", "Australien", "Indien", "Argentinien", "Kasachstan",
"Algerien", "Kongo", "Groenland", "Saudi-Arabien", "Mexiko","Indonesien"];

def generateGeburt():
    vn = random.choice(vornamen);
    nn = random.choice(nachnamen);
    ort = random.choice(orte);
    return {"vorname": vn, "nachname": nn, "geburtsort": ort}

def generateTod():
    vn = random.choice(vornamen);
    nn = random.choice(nachnamen);
    ort = random.choice(orte);
    return {"vorname": vn, "nachname": nn, "todesort": ort}

def generateZuwanderung():
    vn = random.choice(vornamen);
    nn = random.choice(nachnamen);
    land = random.choice(laender);
    return {"vorname": vn, "nachname": nn, "ursprung": land}

def generateAbwanderung():
    vn = random.choice(vornamen);
    nn = random.choice(nachnamen);
    land = random.choice(laender);
    return {"vorname": vn, "nachname": nn, "zielland": land}
