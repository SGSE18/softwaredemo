from confluent_kafka import KafkaError
from confluent_kafka.avro import AvroConsumer
from confluent_kafka.avro.serializer import SerializerError
from config import kafka_loc, schema_reg_loc

c = AvroConsumer({
    'bootstrap.servers': kafka_loc,
    'group.id': 5,
    'schema.registry.url': schema_reg_loc});

c.subscribe(['geburten']);


def main():
    while True:
        try:
            msg = c.poll(10);
        except SerializerError as e:
            print("Deserialisierung fehlgeschlagen {}: {}".format(msg, e));
            break;
        if msg is None:
            continue;
        if msg.error():
            if msg.error().code() == KafkaError._PARTITION_EOF:
                continue;
            else:
                print(msg.error());
                break;
        print("Neue Geburt! " + msg.value()['vorname'] + " " + msg.value()['nachname'] + " aus " + msg.value()['geburtsort']);
    c.close()


if __name__ == "__main__":
    main()
